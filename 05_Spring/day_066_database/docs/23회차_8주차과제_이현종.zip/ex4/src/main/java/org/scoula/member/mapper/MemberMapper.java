package org.scoula.member.mapper;

import org.scoula.member.domain.MemberVO;

import java.util.List;

public interface MemberMapper {
    List<MemberVO> getList();
    MemberVO get(Long no);
    void insert(MemberVO member);
    void update(MemberVO member);
    void delete(Long no);
}
